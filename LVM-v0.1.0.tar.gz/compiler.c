#include "./header/default.h"
#include "./header/string.h"

int main(){
    printf("%lu\n", strToInt("1337"));
}